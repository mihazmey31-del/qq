package ua.netmap.mobile

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.snmp4j.CommunityTarget
import org.snmp4j.PDU
import org.snmp4j.Snmp
import org.snmp4j.SnmpConstants
import org.snmp4j.Target
import org.snmp4j.smi.OID
import org.snmp4j.smi.OctetString
import org.snmp4j.smi.UdpAddress
import org.snmp4j.smi.VariableBinding
import org.snmp4j.transport.DefaultUdpTransportMapping
import java.net.Inet4Address
import java.net.InetAddress
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NetMapScreen(this) }
    }
}

data class LldpNeighbor(val chassisId: String, val portId: String, val portDescription: String, val systemName: String)
data class FdbEntry(val mac: String, val bridgePort: String, val interfaceName: String)
data class SnmpInfo(
    val sysName: String = "", val sysDescr: String = "", val sysServices: String = "",
    val lldp: List<LldpNeighbor> = emptyList(), val fdb: List<FdbEntry> = emptyList(), val error: String? = null
)
data class Device(val ip: String, val hostname: String, val mac: String? = null, val type: String = "host", val snmp: SnmpInfo? = null)
data class NetworkInfo(val ip: String, val gateway: String, val prefix: Int, val cidr: String)

@Composable
fun NetMapScreen(context: Context) {
    val scope = rememberCoroutineScope()
    var network by remember { mutableStateOf(readNetwork(context)) }
    var cidr by remember { mutableStateOf(network?.cidr ?: "192.168.1.0/24") }
    var community by remember { mutableStateOf("public") }
    var useSnmp by remember { mutableStateOf(true) }
    var devices by remember { mutableStateOf(listOf<Device>()) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Готовий до сканування") }
    var selectedTab by remember { mutableIntStateOf(0) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF69B7FF), background = Color(0xFF101820), surface = Color(0xFF1B2732))) {
        Scaffold(containerColor = Color(0xFF101820), topBar = {
            Column(Modifier.fillMaxWidth().background(Color(0xFF17232D)).padding(16.dp)) {
                Text("NETMAP", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("Мережевий сканер · SNMP · LLDP · FDB", color = Color(0xFF9DB1C2), fontSize = 12.sp)
            }
        }) { pad ->
            Column(Modifier.padding(pad).fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2732))) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("Поточне підключення", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("IP смартфона: ${network?.ip ?: "невідомо"}", color = Color(0xFFD5E2EC))
                        Text("Шлюз: ${network?.gateway ?: "невідомо"}", color = Color(0xFFD5E2EC))
                        Text("Підмережа: ${network?.cidr ?: "не визначена"}", color = Color(0xFFD5E2EC))
                    }
                }
                OutlinedTextField(value = cidr, onValueChange = { cidr = it }, label = { Text("Підмережа CIDR") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = useSnmp, onCheckedChange = { useSnmp = it })
                    Text("Опитувати SNMP v2c (sysName / LLDP / FDB)", color = Color.White, fontSize = 13.sp)
                }
                if (useSnmp) OutlinedTextField(value = community, onValueChange = { community = it }, label = { Text("SNMP community (read-only)") }, singleLine = true, modifier = Modifier.fillMaxWidth(), colors = fieldColors())
                Button(onClick = {
                    if (busy) return@Button
                    busy = true; status = if (useSnmp) "Пошук вузлів та SNMP-опитування…" else "Сканування мережі…"
                    scope.launch {
                        try {
                            val result = withContext(Dispatchers.IO) { NetworkScanner.scan(cidr, network?.ip) }
                            val enriched = if (useSnmp) withContext(Dispatchers.IO) {
                                result.map { d -> if (d.type == "scanner") d else d.copy(snmp = SnmpClient.query(d.ip, community.trim())) }
                            } else result
                            devices = enriched
                            val snmpCount = enriched.count { it.snmp?.sysName?.isNotBlank() == true || it.snmp?.error == null && it.snmp != null }
                            status = "Завершено. Вузлів: ${result.size}; SNMP-відповідей: $snmpCount"
                        } catch (e: Exception) { status = "Помилка: ${e.message ?: "перевір CIDR та підключення"}" }
                        finally { busy = false }
                    }
                }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "СКАНУВАННЯ…" else "ПОЧАТИ СКАНУВАННЯ") }
                Text(status, color = Color(0xFF9DB1C2), fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = selectedTab == 0, onClick = { selectedTab = 0 }, label = { Text("Пристрої (${devices.size})") })
                    FilterChip(selected = selectedTab == 1, onClick = { selectedTab = 1 }, label = { Text("Карта") })
                }
                if (selectedTab == 0) {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                        items(devices) { d -> DeviceCard(d) }
                    }
                } else NetworkMap(devices, network?.gateway, Modifier.weight(1f).fillMaxWidth())
                OutlinedButton(onClick = { exportJson(context, cidr, devices) }, enabled = devices.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("ЕКСПОРТ JSON") }
                Text("SNMP v2c не шифрує community. Використовуй read-only community та дозволь UDP/161 лише з довіреної мережі. LLDP/FDB залежать від підтримки комутатором.", color = Color(0xFF8198AA), fontSize = 10.sp)
            }
        }
    }
}

@Composable private fun fieldColors() = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedLabelColor = Color(0xFF69B7FF), unfocusedLabelColor = Color.LightGray)

@Composable
fun DeviceCard(d: Device) {
    var expanded by remember { mutableStateOf(false) }
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2732)), modifier = Modifier.fillMaxWidth(), onClick = { expanded = !expanded }) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(d.snmp?.sysName?.takeIf { it.isNotBlank() } ?: d.hostname, color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("IP: ${d.ip} · MAC: ${d.mac ?: "невідома"}", color = Color(0xFFB9CAD8), fontSize = 12.sp)
                }
                Text(if (d.snmp?.sysName?.isNotBlank() == true) "SNMP" else "L3", color = if (d.snmp?.sysName?.isNotBlank() == true) Color(0xFF79D6A4) else Color(0xFF8198AA), fontSize = 11.sp)
            }
            if (expanded) {
                Divider(color = Color(0xFF405565))
                Text("sysName: ${d.snmp?.sysName?.ifBlank { "—" } ?: "немає відповіді"}", color = Color(0xFFD5E2EC), fontSize = 12.sp)
                Text("sysDescr: ${d.snmp?.sysDescr?.ifBlank { "—" } ?: "—"}", color = Color(0xFFB9CAD8), fontSize = 11.sp)
                Text("sysServices: ${d.snmp?.sysServices ?: "—"}", color = Color(0xFFB9CAD8), fontSize = 11.sp)
                d.snmp?.error?.let { Text("SNMP: $it", color = Color(0xFFFFB27A), fontSize = 11.sp) }
                Text("LLDP сусіди (${d.snmp?.lldp?.size ?: 0})", color = Color(0xFF69B7FF), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                if (d.snmp?.lldp.isNullOrEmpty()) Text("Записів LLDP немає або агент не підтримує LLDP-MIB", color = Color(0xFF8198AA), fontSize = 11.sp)
                d.snmp?.lldp?.forEach { n ->
                    Text("${n.systemName.ifBlank { n.chassisId }} · порт ${n.portId.ifBlank { "—" }} · ${n.portDescription}", color = Color(0xFFD5E2EC), fontSize = 11.sp)
                }
                Text("FDB MAC-адреси (${d.snmp?.fdb?.size ?: 0})", color = Color(0xFF69B7FF), fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                d.snmp?.fdb?.take(100)?.forEach { f -> Text("${f.mac} → ${f.interfaceName.ifBlank { "bridge port ${f.bridgePort}" }}", color = Color(0xFFD5E2EC), fontSize = 11.sp) }
                if ((d.snmp?.fdb?.size ?: 0) > 100) Text("Показано перші 100 записів", color = Color.Gray, fontSize = 10.sp)
            }
            Text(if (expanded) "Натисни, щоб згорнути" else "Натисни для SNMP / LLDP / FDB деталей", color = Color(0xFF8198AA), fontSize = 10.sp)
        }
    }
}

object NetworkScanner {
    suspend fun scan(cidr: String, localIp: String?): List<Device> = withContext(Dispatchers.IO) {
        val p = cidr.substringAfterLast('/', "24").toIntOrNull() ?: 24
        val base = cidr.substringBefore('/')
        val bytes = InetAddress.getByName(base).address
        require(bytes.size == 4 && p in 16..30) { "Підтримуються IPv4-підмережі від /16 до /30" }
        val mask = -1 shl (32 - p)
        val addr = ((bytes[0].toInt() and 255) shl 24) or ((bytes[1].toInt() and 255) shl 16) or ((bytes[2].toInt() and 255) shl 8) or (bytes[3].toInt() and 255)
        val net = addr and mask
        val count = (1 shl (32 - p)) - 2
        require(count <= 1022) { "Завелика мережа: максимум 1024 адреси за один запуск" }
        val found = java.util.Collections.synchronizedList(mutableListOf<Device>())
        val pool = java.util.concurrent.Executors.newFixedThreadPool(48)
        try {
            val tasks = (1..count).map { i -> pool.submit {
                val n = net + i
                val ip = listOf((n ushr 24) and 255, (n ushr 16) and 255, (n ushr 8) and 255, n and 255).joinToString(".")
                if (ip == localIp) { found.add(Device(ip, "Цей смартфон", type = "scanner")); return@submit }
                try { val host = InetAddress.getByName(ip); if (host.isReachable(650)) found.add(Device(ip, host.canonicalHostName.takeIf { it != ip } ?: ip)) } catch (_: Exception) { }
            } }
            tasks.forEach { it.get() }
        } finally { pool.shutdownNow() }
        if (localIp != null && found.none { it.ip == localIp }) found.add(Device(localIp, "Цей смартфон", type = "scanner"))
        found.sortedBy { it.ip.split('.').joinToString("") { part -> part.toInt().toString().padStart(3, '0') } }
    }
}

object SnmpClient {
    private const val SYS_NAME = "1.3.6.1.2.1.1.5.0"
    private const val SYS_DESCR = "1.3.6.1.2.1.1.1.0"
    private const val SYS_SERVICES = "1.3.6.1.2.1.1.7.0"
    private const val LLDP_BASE = "1.0.8802.1.1.2.1.4.1.1."
    private const val FDB_PORT = "1.3.6.1.2.1.17.4.3.1.2"
    private const val BRIDGE_IFINDEX = "1.3.6.1.2.1.17.1.4.1.2"
    private const val IF_NAME = "1.3.6.1.2.1.31.1.1.1.1"

    fun query(ip: String, community: String): SnmpInfo {
        if (community.isBlank()) return SnmpInfo(error = "Community не задана")
        var snmp: Snmp? = null
        return try {
            val transport = DefaultUdpTransportMapping()
            snmp = Snmp(transport)
            transport.listen()
            val target = CommunityTarget<UdpAddress>().apply {
                address = UdpAddress("$ip/161"); this.community = OctetString(community)
                version = SnmpConstants.version2c; timeout = 900; retries = 0
            }
            val basics = get(snmp, target, listOf(SYS_NAME, SYS_DESCR, SYS_SERVICES))
            val name = basics[SYS_NAME].orEmpty()
            val descr = basics[SYS_DESCR].orEmpty()
            val services = basics[SYS_SERVICES].orEmpty()
            val lldpCols = mapOf("5" to "chassis", "7" to "port", "8" to "desc", "9" to "name")
            val lldpMaps = lldpCols.mapValues { (_, col) -> walk(snmp, target, LLDP_BASE + col).toMap() }
            val lldpSuffixes = lldpMaps.values.flatMap { it.keys }.toSet()
            val neighbors = lldpSuffixes.map { suffix ->
                LldpNeighbor(lldpMaps["5"]?.get(suffix).orEmpty(), lldpMaps["7"]?.get(suffix).orEmpty(), lldpMaps["8"]?.get(suffix).orEmpty(), lldpMaps["9"]?.get(suffix).orEmpty())
            }.filter { it.systemName.isNotBlank() || it.portId.isNotBlank() || it.chassisId.isNotBlank() }
            val bridgePorts = walk(snmp, target, BRIDGE_IFINDEX).toMap()
            val ifNames = walk(snmp, target, IF_NAME).toMap()
            val fdb = walk(snmp, target, FDB_PORT).mapNotNull { (suffix, bridgePort) ->
                val mac = suffix.split('.').mapNotNull { it.toIntOrNull() }.takeIf { it.size == 6 }?.joinToString(":") { "%02X".format(it) } ?: return@mapNotNull null
                val ifIndex = bridgePorts[bridgePort]
                FdbEntry(mac, bridgePort, ifIndex?.let { ifNames[it] }.orEmpty())
            }
            SnmpInfo(name, descr, services, neighbors, fdb, if (basics.isEmpty()) "Немає SNMP-відповіді" else null)
        } catch (e: Exception) { SnmpInfo(error = e.message ?: "SNMP timeout / помилка") }
        finally { try { snmp?.close() } catch (_: Exception) { } }
    }

    private fun get(snmp: Snmp, target: Target<UdpAddress>, oids: List<String>): Map<String, String> {
        val pdu = PDU().apply { type = PDU.GET; oids.forEach { add(VariableBinding(OID(it))) } }
        val response = snmp.get(pdu, target).response ?: return emptyMap()
        if (response.errorStatus != PDU.noError) return emptyMap()
        return response.variableBindings.associate { it.oid.toString() to it.variable.toString() }
    }

    private fun walk(snmp: Snmp, target: Target<UdpAddress>, root: String): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        var cursor = OID(root)
        repeat(512) {
            val pdu = PDU().apply { type = PDU.GETNEXT; add(VariableBinding(cursor)) }
            val response = snmp.getNext(pdu, target).response ?: return out
            if (response.errorStatus != PDU.noError || response.variableBindings.isEmpty()) return out
            val vb = response.variableBindings[0]
            if (!vb.oid.startsWith(OID(root)) || vb.oid <= cursor) return out
            cursor = vb.oid
            out.add(vb.oid.toString().removePrefix("$root.") to vb.variable.toString())
        }
        return out
    }
}

@Composable
fun NetworkMap(devices: List<Device>, gateway: String?, modifier: Modifier = Modifier) {
    Column(modifier.background(Color(0xFF14212B), RoundedCornerShape(12.dp)).padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Шлюз / маршрутизатор", color = Color(0xFF69B7FF), fontSize = 12.sp)
        Box(Modifier.size(54.dp).background(Color(0xFF285477), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text("GW", color = Color.White, fontWeight = FontWeight.Bold) }
        Text(gateway ?: "Шлюз не визначено", color = Color.LightGray, fontSize = 11.sp)
        Canvas(Modifier.fillMaxWidth().height(28.dp)) { drawLine(Color(0xFF52748D), Offset(size.width / 2, 0f), Offset(size.width / 2, size.height), 2.dp.toPx()); drawLine(Color(0xFF52748D), Offset(size.width * .1f, size.height), Offset(size.width * .9f, size.height), 2.dp.toPx()) }
        if (devices.isEmpty()) Text("Запусти сканування, щоб побачити вузли", color = Color.LightGray, modifier = Modifier.padding(20.dp))
        else devices.chunked(3).forEach { row -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) { row.forEach { d ->
            Column(Modifier.weight(1f).padding(3.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(40.dp).background(if (d.type == "scanner") Color(0xFF26745F) else Color(0xFF344C60), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) { Text(if (d.type == "scanner") "ME" else "PC", color = Color.White, fontSize = 11.sp) }
                Text(d.ip.substringAfterLast('.'), color = Color.White, fontSize = 11.sp)
                Text(d.snmp?.sysName?.takeIf { it.isNotBlank() } ?: d.hostname.take(12), color = Color(0xFF9DB1C2), fontSize = 9.sp, maxLines = 1)
            }
        } } }
    }
}

fun readNetwork(context: Context): NetworkInfo? {
    return try {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return null
        val lp: LinkProperties = cm.getLinkProperties(net) ?: return null
        val ip = lp.linkAddresses.mapNotNull { it.address as? Inet4Address }.firstOrNull() ?: return null
        val route = lp.routes.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }
        val prefix = lp.linkAddresses.firstOrNull { it.address == ip }?.prefixLength ?: 24
        val raw = ip.address
        val value = ((raw[0].toInt() and 255) shl 24) or ((raw[1].toInt() and 255) shl 16) or ((raw[2].toInt() and 255) shl 8) or (raw[3].toInt() and 255)
        val mask = if (prefix == 0) 0 else -1 shl (32 - prefix)
        val n = value and mask
        val networkIp = listOf((n ushr 24) and 255, (n ushr 16) and 255, (n ushr 8) and 255, n and 255).joinToString(".")
        NetworkInfo(ip.hostAddress ?: "", route?.gateway?.hostAddress ?: "", prefix, "$networkIp/$prefix")
    } catch (_: Exception) { null }
}

fun exportJson(context: Context, cidr: String, devices: List<Device>) {
    val root = JSONObject().put("network", cidr).put("createdAt", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(Date()))
    val arr = JSONArray()
    devices.forEach { d ->
        val node = JSONObject().put("ip", d.ip).put("hostname", d.hostname).put("mac", d.mac ?: JSONObject.NULL).put("type", d.type)
        d.snmp?.let { s ->
            val snmp = JSONObject().put("sysName", s.sysName).put("sysDescr", s.sysDescr).put("sysServices", s.sysServices).put("error", s.error ?: JSONObject.NULL)
            val lldp = JSONArray(); s.lldp.forEach { lldp.put(JSONObject().put("chassisId", it.chassisId).put("portId", it.portId).put("portDescription", it.portDescription).put("systemName", it.systemName)) }
            val fdb = JSONArray(); s.fdb.forEach { fdb.put(JSONObject().put("mac", it.mac).put("bridgePort", it.bridgePort).put("interfaceName", it.interfaceName)) }
            node.put("snmp", snmp.put("lldpNeighbors", lldp).put("fdbEntries", fdb))
        }
        arr.put(node)
    }
    root.put("nodes", arr)
    val name = "netmap-${System.currentTimeMillis()}.json"
    context.openFileOutput(name, Context.MODE_PRIVATE).use { it.write(root.toString(2).toByteArray()) }
    val file = java.io.File(context.filesDir, name)
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "application/json"; putExtra(android.content.Intent.EXTRA_STREAM, androidx.core.content.FileProvider.getUriForFile(context, context.packageName + ".provider", file)); addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    try { context.startActivity(android.content.Intent.createChooser(intent, "Експорт NetMap JSON")) } catch (_: Exception) { }
}
